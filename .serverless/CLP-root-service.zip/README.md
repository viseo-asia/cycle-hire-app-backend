# AWS credential setup URL
https://docs.aws.amazon.com/cli/latest/userguide/cli-chap-getting-started.html

# Deploy to AWS lambda
sls deploy --region ap-southeast-1

# run to local server
sls offline start

# logging
sls logs -f <fuctionName>